package com.goblin.javaweb_filter_listener.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@WebServlet(urlPatterns = {"/register"})
public class RegisterServlet extends HttpServlet {

    // HashMap存储键值对，例（{键（键username，值tom），值（键password，值123456）}）。类似于键值对的嵌套
    private static Map<String, String> userInfo = new HashMap<>();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        // 先存入哈希表
        userInfo.put(username, password);
        resp.sendRedirect(req.getContextPath() + "/login.jsp");
    }

    // 验证输入的信息是否与map中的用户信息匹配,必须使用static，否则无法在其他类中使用该方法
    public static boolean isValid(String username, String password) {
        return userInfo.containsKey(username) && userInfo.get(username).equals(password);
    }
}
