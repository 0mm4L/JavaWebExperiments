package com.goblin.javaweb_filter_listener.listener;

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpServletRequest;
import java.time.Instant;
import java.util.Date;
import java.util.logging.Logger;

@WebListener
public class RequestListener implements ServletRequestListener {
//Logger.getLogger 方法用于获取或创建日志
    private static final Logger logger = Logger.getLogger("RequestLogger");

    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        HttpServletRequest req = (HttpServletRequest) sre.getServletRequest();

        Date reqStartDate = new Date();
        long reqStartTime = System.currentTimeMillis();

        req.setAttribute("reqStartDate", reqStartDate);
        req.setAttribute("reqStartTime", reqStartTime);

        String reqIp = req.getRemoteAddr();
        String reqMethod = req.getMethod();
        String reqUri = req.getRequestURI();
        String reqQueryString = req.getQueryString() != null ? req.getQueryString() : "无查询参数";
        String reqUserAgent = req.getHeader("User-Agent");
        System.out.println("目前的请求开始的时间为 " + reqStartDate);

        // 使用 Logger 记录请求的详细信息
        logger.info(String.format("请求发起时间：%s, 客户端ip：%s, 请求方法：%s, 请求URI：%s, 请求查询参数：%s, 请求User-Agent：%s",
                reqStartDate, reqIp, reqMethod, reqUri, reqQueryString, reqUserAgent));

    }

    @Override
    public void requestDestroyed(ServletRequestEvent sre) {

        HttpServletRequest req = (HttpServletRequest) sre.getServletRequest();

        Date reqStartDate = (Date) req.getAttribute("reqStartDate");
        long reqStartTime = (Long) req.getAttribute("reqStartTime");

        Date reqDiedDate = new Date();
        long reqDiedTime = System.currentTimeMillis();
        long reqLifeTime = reqDiedTime - reqStartTime;
        System.out.println("目前请求结束时间为" + reqDiedDate);
        System.out.println("该请求处理时间为" + reqLifeTime + "ms");

        logger.info(String.format("请求结束时间：%s, 请求处理时间：%d ms",
                reqDiedDate, reqLifeTime));
    }
}
