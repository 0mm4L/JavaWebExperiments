package com.goblin.javaweb_filter_listener.filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@WebFilter(filterName = "LoginFilter", urlPatterns = {"/*"})
public class LoginFilter implements Filter {

    private static final List<String> allowPaths = Arrays.asList("/req_listener","/login.jsp", "/register.jsp", "/index.jsp","/login","/register","/error.jsp");

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void destroy() {

    }


    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) servletRequest;
        HttpServletResponse resp = (HttpServletResponse) servletResponse;
        //若已有会话，则返回该会话；没有会话则返回null，不会创建新会话
        HttpSession session = req.getSession(false);
        //获取uri
        String uri = req.getRequestURI();
        //获取上下文路径
        String contextPath = req.getContextPath();
        // 去除上下文路径，保留相对路径
        String path = uri.substring(contextPath.length());

        if(allowPaths.contains(path)){
            filterChain.doFilter(servletRequest, servletResponse);
        } else if (session != null && session.getAttribute("username") != null && session.getAttribute("password") != null) {
            filterChain.doFilter(servletRequest, servletResponse);
        }
        else {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
        }
    }
}
